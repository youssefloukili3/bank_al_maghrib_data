package com.vogella.maven.quickstart;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.BrowserVersion;

public class AppBam 
{// l attribut pathe contient le chemin de telechargement dont vous voulez stocker les données 
	public static String pathe="/home/youssef/Documents/";
	public static Scanner inputlink=new Scanner(System.in);
	public static Scanner debut_archive=new Scanner(System.in);

	
	public static void main( String[] args ) throws InterruptedException 
    {
    	
		//il est demandé de telecharger, extraire et indiquer le chemin d'un webdriver pour que java interagit avec le navigateur  
		System.setProperty("webdriver.gecko.driver","/home/youssef/Desktop/geckodriver");
        
		///home/youssef/Documents/projet data store/Bank Al-Maghrib
       
        FirefoxProfile profile=new FirefoxProfile();
        
        profile.setPreference("browser.download.folderList", 1);
        profile.setPreference("browser.download.dir", pathe);
        profile.setPreference("browser.helperApps.alwaysAsk.force", false);
        profile.setPreference("browser.helperApps.neverAsk.saveToDisk","application/octet-stream");
       // profile.setPreference("browser.download.manager.closeWhenDone", false);
        
        
        WebDriver driver = new FirefoxDriver(profile);
        
        //pour le cas present le lien à naviguer est le suivant
        System.out.println("saisissez le lien de telechargement :");
        String link=inputlink.nextLine();
       
        
       
        
       	driver.get(link);
     
      	 System.out.println("saisis la premiere année d'archive");
         int annee=debut_archive.nextInt();
        //l'inspection par l'outil du navigateur indique le champ 'year' qui sera modifié a chaque tour de boucle pour extraire les données de chaque année   
		
        WebElement element = driver.findElement(By.id("year"));
	
	
        int valeur_int=2017;
        String valeur=element.getAttribute("value");
        
        while(valeur_int>=annee)
       {
        	
        //Enter something to search for
        element.clear();	
        element.sendKeys(valeur);
        element.submit();
       
        System.out.println("envoie de valeur de l'annee "+valeur+" est effectue");
        
        //le champ du lien de telechargement est le suivant, il sera stocké dans l'element suivant 'download'
        
        
        List<WebElement> download=driver.findElements(By.xpath("//a[@title='Téléchargement CSV']"));
        
        for(WebElement parser : download)
        {	
        	parser.click();
        	
        }
        System.out.println("telechargement.......");
       
        valeur_int = Integer.parseInt(valeur);
        valeur_int--;
        valeur = Integer.toString(valeur_int);
        
               
        System.out.println("Page title is: " + driver.getTitle());
       	}
    }
}
